<html lang="id">
    <head>
    <title>Starter Page</title>
    <meta name="viewport" content="width=device-width, user-scalable=no">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="assets/toastr/toastr.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/ubuntu.css">
    <link rel="stylesheet" href="assets/css/theme-green.css">
    <style type="text/css">
        *{font-family: 'Ubuntu';}
        a{text-decoration:none;}
        input,select,textarea{outline:none;border:none!important;}
        table,th,td{
            padding-top:2px!important ;
            padding-bottom:2px!important;

        }
        .logo{
            min-width:150px!important;
            min-height:150px!important;
            max-width:150px!important;
            max-height:150px!important;
        }
        .blink{ 
            animation: animate 1s linear infinite; 
        }
        @keyframes animate{ 
            0%{ 
                opacity: 0; 
            }
            50%{ 
                opacity: 0.7; 
            }
            100%{ 
                opacity: 0; 
            } 
        }
        .sidebar{
            color: #FFF;
            background: #394359!important;
            color: #FFF;
        }
    </style>
    </head>
    <body class="light-gray">
        <script type="text/javascript" src="assets/js/jquery.min.js"></script>
        <script type="text/javascript" src="assets/toastr/toastr.min.js"></script>
        <script type="text/javascript" src="assets/js/loadingoverlay.min.js"></script>
        
        <div class="bar top large theme" style="z-index:4;">
            <button class="bar-item button hover-none" onclick="nav_open()"><i class="fa fa-bars"></i> Menu</button>
            <a href="?view=topup" class="button right"><i class="fa fa-money"></i> Rp 475,000</a>
        </div>

        <nav class="sidebar collapse animate-left card-4" style="z-index:3;width:200px;" id="mySidebar"><br>
            <div class="bar-block">
                <a href="./" class="bar-item button padding"><i class="fa fa-home fa-fw"></i> Dashboard</a>
            </div>
        </nav>

        <div class="overlay hide-large animate-opacity" onclick="nav_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>
        <div class="main" style="margin-left:200px;margin-top:43px;">
            <div class="container margin-top">
                Container Main
            </div>
        </div>

        <script type="text/javascript" src="https://app.sandbox.midtrans.com/snap/assets/snap.js" data-client-key="SB-Mid-client-f2wz2uxAzFc2zAj6"></script>
        <script type="text/javascript">
            var mySidebar = document.getElementById("mySidebar");
            var overlayBg = document.getElementById("myOverlay");
            function nav_open() {
                if (mySidebar.style.display === 'block') {
                    mySidebar.style.display = 'none';
                    overlayBg.style.display = "none";
                } else {
                    mySidebar.style.display = 'block';
                    overlayBg.style.display = "block";
                }
            }
            function nav_close() {
                mySidebar.style.display = "none";
                overlayBg.style.display = "none";
            }

            $.LoadingOverlay("show", {
                image       : "",
                fontawesome : "fa fa-cog fa-spin"
            });
            $(document).ready(function(){
                setTimeout(function(){
                    $.LoadingOverlay("hide");
                    $("body").removeClass("hide");
                },1000);
            });

            snap.pay('SNAP-TOKEN', {
                onSuccess: function(result){console.log('success');console.log(result);},
                onPending: function(result){console.log('pending');console.log(result);},
                onError: function(result){console.log('error');console.log(result);},
                onClose: function(){console.log('customer closed the popup without finishing the payment');}
            });
        </script>
    </body>
</html>

