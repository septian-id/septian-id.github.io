<?php
    class Midtrans{
        private $curl;
        private $url;
        function __construct($serverKey){
            $this->serverKey = $serverKey;
            $this->auth = base64_encode("$this->serverKey:");
            $this->url = "https://app.sandbox.midtrans.com/snap/v1/transactions";
        }
        function getToken($data){
            $this->curl = curl_init();
            curl_setopt_array($this->curl, [
                CURLOPT_URL => $this->url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => json_encode($data),
                CURLOPT_HTTPHEADER => [
                    "accept: application/json",
                    "authorization: Basic $this->auth",
                    "content-type: application/json"
                ],
            ]);
            $this->response = curl_exec($this->curl);
            $this->err = curl_error($this->curl);
            curl_close($this->curl);
            if ($this->err) {
                echo json_encode(["token" => $this->err]);
            }
            else{
                $this->data = json_decode($this->response);
                return json_encode(["token" => $this->data->token]);
            }
        }
    }
    /*
    $mid = new Midtrans("SB-Mid-server-lvmCApa0sEuRhJB7wAqvQ_mh");
    $token = $mid->getToken([
        'transaction_details' => [
            'order_id' => rand(),
            'gross_amount' => 10000
        ],
        "item_details" => [
            "id" => "ITEM1",
            "price" => 10000,
            "quantity" => 1,
            "name" => "Midtrans Bear",
            "brand" => "Midtrans",
            "category" => "Toys",
            "merchant_name" => "Midtrans",
            "url" => "https://tokobuah.com/apple-fuji",
            "kode_voucher" => rand()
        ],
        "customer_details" => [
            "first_name" => "TEST",
            "last_name" => "MIDTRANSER",
            "email" => "test@midtrans.com",
            "phone" => "+628123456",
        ],
        "callbacks" => [
            "finish" => "https://example.com/"
        ]
    ]);
    echo $token;
    */